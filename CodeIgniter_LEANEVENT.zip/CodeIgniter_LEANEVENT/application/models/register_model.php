<?php

class register_model extends CI_Model{

	public function insert_data($email,$pwd,$fn,$ln){

		$query="INSERT into `users`(email,password,fname,lname,roleId) values('$email','$pwd','$fn','$ln',1)";
 		$result = $this->db->query($query);


 		if ( ! $result)
    {
       echo "error";
    }

		
	}

	public function insert_data2($email2,$pwd2,$fn2,$ln2){

		$query="INSERT into `users`(email,password,fname,lname,roleId) values('$email','$pwd','$fn','$ln',3)";
 		$result = $this->db->query($query);

 			if ($conn->query($query) === TRUE) {
        echo "Contact Info Added Successfully";
      } else {
            echo "Error: " . $query . "<br>" . $conn->error;
            echo "Unable to add contact information !!!";
          }

		
	}

	public function insert_data1($email1,$pwd1,$fn1,$ln1){

		$query="INSERT into `users`(email,password,fname,lname,roleId) values('$email','$pwd','$fn','$ln',2)";
 		$result = $this->db->query($query);

 		if ( ! $result)
    {
       echo "error";
    }
		
	}
	
}

?>
