<?php
	class My_db extends CI_Model{

		public function val_contact($data){
			

			$this->db->insert('contact-us',$data);
			#return 'inserted successfully';
		}

		public function val_client($data,$data2){
			
			$this->db->insert('client',$data);
			$this->db->insert('user',$data2);

		}

		public function register($data){
			
			$this->db->insert('users',$data);
		//	$this->db->insert('user',$data2);

		}

		public function val_login($username,$login_pwd){

			#$this->db->like('email',$email);
			$this->db->where('email', $username);
			$this->db->where('password', $login_pwd);
			$query= $this->db->get('users');

			if ($query->num_rows() > 0) {
        		return true;
    		} 
    		else {
        		return false;
    		}

		}

		public function get_username($username){
			$sql = "SELECT * FROM users where email = '$username'";
			$query=$this->db->query($sql,$username);
			$rows=$query->row_array();

			$username = $rows['email'];
		//	$roleId = $rows['roleId'];

			return $username;

			//return $roleId;
		}

		public function get_username1($username){
			$sql = "SELECT * FROM users where email = '$username'";
			$query=$this->db->query($sql,$username);
			$rows=$query->row_array();

			//$username = $rows['email'];
			$roleId = $rows['roleId'];

			//return $username;

			return $roleId;
		}


	}
?>