<?php

class contact_model extends CI_Model{

	public function insert_data($fn,$ln,$email,$topic,$msg){

		$query="INSERT into `contact-us` values('$fn','$ln','$email','$topic','$msg')";
 		$this->db->query($query);
		
	}
	
}

?>
