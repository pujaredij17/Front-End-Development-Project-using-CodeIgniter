<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct(){
		parent::__construct();
		$this->load->helper(array('url','form','email'));	
	}
	
	public function index()
	{
		$this->load->view('welcome_message');
	}

public function register()
	{
		$resp=array('message'=>'Required information is marked with an asterisk (*)');
		$this->load->view('register',$resp);

	}
public function buy_from_us()
	{
		$resp=array('message'=>'Required information is marked with an asterisk (*)');
		$this->load->view('buy_from_us',$resp);

	}	

public function contact_us()
	{

		$resp=array('message'=>'Required information is marked with an asterisk (*)');
		$this->load->view('contact_us',$resp);
	}	

public function home_individual()
	{

		$resp=array('message'=>'Required information is marked with an asterisk (*)');
		$this->load->view('home_individual',$resp);
	}	


public function login()
	{
		$resp=array('message'=>'Required information is marked with an asterisk (*)');
		$this->load->view('login',$resp);
	}	

public function Login_controller(){

		$this->load->library('form_validation');
		$this->form_validation->set_rules('username','Email','required|max_length[40]');
		$this->form_validation->set_rules('login_pwd','Password','required');
		
		if($this->form_validation->run()==TRUE){
			$this->load->model('My_db','m');

			$username=$this->input->post('username');
			$login_pwd=$this->input->post('login_pwd');

			if($result=$this->m->val_login($username,$login_pwd))
			{

				$usern = $this->m->get_username($username);

				$roleId = $this->m->get_username1($username);
			
				$session_data = array(
					'user' => $usern,
					'roleId' => $roleId
				);

				$this->session->set_userdata($session_data);
				redirect(base_url().'index.php/welcome/enter');
				//redirect(base_url().'welcome/Contact_us_controller');

			}
			else{
				$this->session->set_flashdata('error','invalid username and password');
		     	$this->load->view('login',$resp);
			}


		}
		else{
			$resp=array('message'=>'Required information is marked with an asterisk (*)');
			$this->load->view('login',$resp);
		}

	}

	
public function Register_controller(){

		$this->load->library('form_validation');

		$this->form_validation->set_rules('Nombre_reg','First Name','required|alpha|max_length[20]');
		$this->form_validation->set_rules('Apellido_reg','Last Name','required|alpha|max_length[20]');
		$this->form_validation->set_rules('email_reg','E-mail','required|valid_email|max_length[40]');
		$this->form_validation->set_rules('pwd_reg','Password','required');
		//$this->form_validation->set_rules('phone01','Phone','numeric|max_length[10]');
		//$this->form_validation->set_rules('b_name','Business name','max_length[40]');


		if($this->form_validation->run()==TRUE){

			$this->load->model('My_db','m');

			$Nombre_reg=$this->input->post('Nombre_reg');
			$Apellido_reg=$this->input->post('Apellido_reg');
			$email_reg=$this->input->post('email_reg');
			$pwd_reg=$this->input->post('pwd_reg');
		//	$b_name=$this->input->post('b_name');

			$data=array(
				'fname'=>$Nombre_reg,
				'lname'=>$Apellido_reg,
				'email'=>$email_reg,
				'password'=>$pwd_reg,
				'roleId'=> 1,
			//	'pwd_reg'=>$b_name,
				);

			// $data2=array(
			// 	'email'=>$email01,
			// 	'password'=>'1234567',
			// 	'rid'=>2);

			#calling the model
			$this->m->register($data);

			$resp=array('message'=>'Account Created Successfully!, Please check your email for further detail');
			
			$this->load->view('register',$resp);
		}

		else{
			$resp=array('message'=>'Required information is marked with an asterisk (*)');
			$this->load->view('register',$resp);
		}
	}

public function Register_controller_agentlean(){

		$this->load->library('form_validation');

		$this->form_validation->set_rules('Nombre_reg1','First Name','required|alpha|max_length[20]');
		$this->form_validation->set_rules('Apellido_reg1','Last Name','required|alpha|max_length[20]');
		$this->form_validation->set_rules('email_reg1','E-mail','required|valid_email|max_length[40]');
		$this->form_validation->set_rules('pwd_reg1','Password','required');
		//$this->form_validation->set_rules('phone01','Phone','numeric|max_length[10]');
		//$this->form_validation->set_rules('b_name','Business name','max_length[40]');


		if($this->form_validation->run()==TRUE){

			$this->load->model('My_db','m');

			$Nombre_reg1=$this->input->post('Nombre_reg1');
			$Apellido_reg1=$this->input->post('Apellido_reg1');
			$email_reg1=$this->input->post('email_reg1');
			$pwd_reg1=$this->input->post('pwd_reg1');
		//	$b_name=$this->input->post('b_name');

			$data=array(
				'fname'=>$Nombre_reg1,
				'lname'=>$Apellido_reg1,
				'email'=>$email_reg1,
				'password'=>$pwd_reg1,
				'roleId'=> 2,
			//	'pwd_reg'=>$b_name,
				);

			// $data2=array(
			// 	'email'=>$email01,
			// 	'password'=>'1234567',
			// 	'rid'=>2);

			#calling the model
			$this->m->register($data);

			$resp=array('message'=>'Account Created Successfully!, Please check your email for further detail');
			
			$this->load->view('register',$resp);
		}

		else{
			$resp=array('message'=>'Required information is marked with an asterisk (*)');
			$this->load->view('register',$resp);
		}
	}	

public function Register_controller_business(){

		$this->load->library('form_validation');

		$this->form_validation->set_rules('Nombre_reg2','First Name','required|alpha|max_length[20]');
		$this->form_validation->set_rules('Apellido_reg2','Last Name','required|alpha|max_length[20]');
		$this->form_validation->set_rules('email_reg2','E-mail','required|valid_email|max_length[40]');
		$this->form_validation->set_rules('pwd_reg2','Password','required');
		//$this->form_validation->set_rules('phone01','Phone','numeric|max_length[10]');
		//$this->form_validation->set_rules('b_name','Business name','max_length[40]');


		if($this->form_validation->run()==TRUE){

			$this->load->model('My_db','m');

			$Nombre_reg2=$this->input->post('Nombre_reg2');
			$Apellido_reg2=$this->input->post('Apellido_reg2');
			$email_reg2=$this->input->post('email_reg2');
			$pwd_reg2=$this->input->post('pwd_reg2');
		//	$b_name=$this->input->post('b_name');

			$data=array(
				'fname'=>$Nombre_reg2,
				'lname'=>$Apellido_reg2,
				'email'=>$email_reg2,
				'password'=>$pwd_reg2,
				'roleId'=> 3,
			//	'pwd_reg'=>$b_name,
				);

			// $data2=array(
			// 	'email'=>$email01,
			// 	'password'=>'1234567',
			// 	'rid'=>2);

			#calling the model
			$this->m->register($data);

			$resp=array('message'=>'Account Created Successfully!, Please check your email for further detail');
			
			$this->load->view('register',$resp);
		}

		else{
			$resp=array('message'=>'Required information is marked with an asterisk (*)');
			$this->load->view('register',$resp);
		}
	}		

public function Contact_us_controller()
	{
		#Form Validation
		$this->load->library('form_validation');
		
		 $this->form_validation->set_rules('usr', 'Nombre', array('trim','required','min_length[3]','max_length[30]','alpha'));
	        $this->form_validation->set_rules('lname', 'Apellido', 'trim|required|min_length[3]|max_length[30]|alpha');
	        $this->form_validation->set_rules('email', 'Correo', 'required|regex_match[/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/]');
	        $this->form_validation->set_rules('topic', 'Tema', 'required|min_length[3]|max_length[30]|alpha_numeric');
	        $this->form_validation->set_rules('message', 'Mensange', 'required|min_length[5]|max_length[200]');

		
		if($this->form_validation->run()==TRUE){
			
			#load the model
			$this->load->model('My_db','m');

			$usr=$this->input->post('usr');
			$lname=$this->input->post('lname');
			$email=$this->input->post('email');
			$topic=$this->input->post('topic');
			$message=$this->input->post('message');

			$data=array(
				'fname'=>$usr,
				'lname'=>$lname,
				'email'=>$email,
				'topic'=>$topic,
				'msg'=>$message,
				);

			$this->m->val_contact($data);

			$resp=array('message'=>'Data Inserted Successfully, we will contact you soon');
			
			$this->load->view('contact_us',$resp);
		}

		else{
			$resp=array('message'=>'Required information is marked with an asterisk (*)');
			$this->load->view('contact_us',$resp);
		}
	}

public function Buy_from_us_controller()
	{
		// 	$this->load->library('form_validation');
		// $this->form_validation->set_rules('username','Email','required|max_length[40]');
		// $this->form_validation->set_rules('login_pwd','Password','required');
		
		// if($this->form_validation->run()==TRUE){
			// $this->load->model('My_db','m');

			// $username=$this->input->post('username');
			// $login_pwd=$this->input->post('login_pwd');

			// if($result=$this->m->val_login($username,$login_pwd))
			// {

			// 	$usern = $this->m->get_username($username);

			// 	$roleId = $this->m->get_username1($username);
			
			// 	$session_data = array(
			// 		'user' => $usern,
			// 		'roleId' => $roleId
			// 	);

			// 	$this->session->set_userdata($session_data);
			// 	redirect(base_url().'index.php/welcome/enter');
			// 	//redirect(base_url().'welcome/Contact_us_controller');

			// }
			// else{
			//	$this->session->set_flashdata('error','invalid username and password');
					$resp=array('message'=>'Required information is marked with an asterisk (*)');

		     	$this->load->view('buy_from_us',$resp);
			// }


		// }
		// else{
		// 	$resp=array('message'=>'Required information is marked with an asterisk (*)');
		// 	$this->load->view('login',$resp);
		// }
	}	

	public function enter()
	{
					//$this->load->view('contact_us',$resp);


		$username = $this->session->userdata('user');
		$roleId =$this->session->userdata('roleId');
		if($roleId == 1)
		{
			redirect(base_url().'index.php/welcome/Home_individual_controller');

		}
		if($roleId == 2)
		{
			redirect(base_url().'index.php/welcome/Home_agent_controller');

		}
		if($roleId == 3)
		{
			redirect(base_url().'index.php/welcome/Home_business_controller');

		}
		else
		{
			//redirect(base_url().)

		}

		
	}

public function Home_individual_controller()
	{
		#Form Validation
		// $this->load->library('form_validation');
		
		//  $this->form_validation->set_rules('usr', 'Nombre', array('trim','required','min_length[3]','max_length[30]','alpha'));
	 //        $this->form_validation->set_rules('lname', 'Apellido', 'trim|required|min_length[3]|max_length[30]|alpha');
	 //        $this->form_validation->set_rules('email', 'Correo', 'required|regex_match[/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/]');
	 //        $this->form_validation->set_rules('topic', 'Tema', 'required|min_length[3]|max_length[30]|alpha_numeric');
	 //        $this->form_validation->set_rules('message', 'Mensange', 'required|min_length[5]|max_length[200]');

		
		// if($this->form_validation->run()==TRUE){
			
		// 	#load the model
		// 	$this->load->model('My_db','m');

		// 	$usr=$this->input->post('usr');
		// 	$lname=$this->input->post('lname');
		// 	$email=$this->input->post('email');
		// 	$topic=$this->input->post('topic');
		// 	$message=$this->input->post('message');

		// 	$data=array(
		// 		'fname'=>$usr,
		// 		'lname'=>$lname,
		// 		'email'=>$email,
		// 		'topic'=>$topic,
		// 		'msg'=>$message,
		// 		);

		// 	$this->m->val_contact($data);

		 	$resp=array('message'=>'Data Inserted Successfully, we will contact you soon');
			
			$this->load->view('home_individual',$resp);
		// }

		// else{
		// //	$resp=array('message'=>'Required information is marked with an asterisk (*)');
		// 	$this->load->view('home_individual',$resp);
		// }
	}	

	public function Home_business_controller()
	{
		

		 	$resp=array('message'=>'Data Inserted Successfully, we will contact you soon');
			
			$this->load->view('home_business',$resp);
		
	}	

	public function Home_agent_controller()
	{
		

		 	$resp=array('message'=>'Data Inserted Successfully, we will contact you soon');
			
			$this->load->view('home_agent',$resp);
		
	}	
public function Single_product1_controller()
	{
		

		 	$resp=array('message'=>'Data Inserted Successfully, we will contact you soon');
			
			$this->load->view('single_product1',$resp);
		
	}	



}