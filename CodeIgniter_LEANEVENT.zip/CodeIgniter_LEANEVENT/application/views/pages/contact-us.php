<!-- <?php

//$servername = "167.99.105.36";
$servername = "localhost";
$username = "root";

// Create connection
$conn = new mysqli($servername, $username ,'','leanevent');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

function validate_alpha($data) {
    $data = test_input($data);
    $data = (preg_match("/^[a-zA-Z ]+$/",$data)) ? $data : "";
    return $data;
}

function validate_email($data) {
    $data = test_input($data);
    $data = (preg_match("/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/",$data)) ? $data : "";
    return $data;
}

function validate_alphanum($data){
      $data = test_input($data);
      $data = (preg_match("/^[a-zA-Z0-9 ]*$/", $data)) ? $data : "";
      return $data;
}

function validate() {
  if (isset($_POST['submit'])) {
     $fname = validate_alpha($_POST['usr']);
    $lname = validate_alpha($_POST['lname']);
    $email = validate_email($_POST['email']);
    $topic = validate_alphanum($_POST['topic']);

    /* $fname = $_POST['usr'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
*/
    
    return !empty($fname) and !empty($lname) and !empty($email and !empty($topic)) ;
  }
  return false;
}
?>
 -->


      
      
	  
	 <!--begin:inner-media-page-widget -->
     <div class="inner-media-page-widget">
           <div class="media-banner">
          	  <img src="<?php echo base_url(); ?>assets/images/bannercontacto.jpg">
           </div>           
        <div class="container banner-txt-area">
            <div class="zis-md-12">
                <h1 class="main-heading">CONTACTO</h1>
                <div class="sub-heading"><span>Inicio</span><b>CONTACTO</b></div>
            </div>
        </div>
     </div>
     <!--begin:inner-media-page-widget -->
     
     
     <!--begin:contact-info-section -->
     <div class="contactus-info-section">
		<div class="container">        
        	<h3>Información del contacto</h3>
			<div class="zis-md-3">
            	<div class="ct-address">198 West 21th Street,<br>Suite 721 New York NY 10016</div>
            </div> 
            <div class="zis-md-3">
            	<div class="ct-phone">+ 213564987</div>
            </div> 
            <div class="zis-md-3">
            	<div class="ct-info">info@diazapps.com</div>
            </div> 
            <div class="zis-md-3">
            	<div class="ct-web">diazapps.com</div>
            </div> 
		</div>
	 </div>
	 <!--end:contact-info-section -->
     
     <!--begin:contact-info-section -->
     <div class="contactus-social-section">
		<div class="container"> 
       	 <h3>LEAN en las redes sociales</h3>       
			<div class="zis-md-3">
            	<div class="media"><img src="<?php echo base_url(); ?>assets/images/ct-fb.png"><a href="#" class="link">LEAN Ayuda Humanitaria</a></div>
            </div> 
            <div class="zis-md-3">
            	<div class="media"><img src="<?php echo base_url(); ?>assets/images/ct-twitter.png"><a href="#" class="link">@LeanEmergente</a></div>
            </div> 
            <div class="zis-md-3">
            	<div class="media"><img src="<?php echo base_url(); ?>assets/images/ct-inst.png"><a href="#" class="link">@LeanAyudaHumanitaria</a></div>
            </div> 
            <div class="zis-md-3">
            	<div class="media"><img src="<?php echo base_url(); ?>assets/images/ct-email.png"><a href="#" class="link">lean.emergente@gmail.com</a></div>
            </div> 
		</div>
	 </div>
	 <!--end:contact-info-section -->   
     
     
     <!--begin:inner-media-page-widget -->
    
     <div class="logo-form">
     	<div class="container-logo">     	
                <!--form id="login-form" name="login-form" method="POST"-->
                <?php echo form_open('Contact_us/view'); ?>
                	<h3>Estar en contacto</h3>
                    <div class="row">
                    	<div class="zis-md-6">
                        	<div class="form-group">
                              <label for="usr">Nombre</label>
                              <input type="text" class="form-control" id="usr" name="usr" placeholder="Tu Nombre" >
                                              <?php echo form_error('usr'); ?>
                            </div>
                        </div>                        
                        <div class="zis-md-6">
                        	<div class="form-group">
                              <label for="pwd">Apellido</label>
                              <input type="text" class="form-control" id="lname" name="lname" placeholder="Tu Apellido" maxlength="32"  >
                                              <?php echo form_error('lname'); ?>

                            </div>
                        </div>
                        <div class="zis-md-12">
                        	<div class="form-group">
                              <label for="pwd">Correo</label>
                              <input type="email" class="form-control" id="email" name="email" placeholder="Tu correo electrónico"  >
                                              <?php echo form_error('email'); ?>
                            </div>
                        </div>
                        <div class="zis-md-12">
                        	<div class="form-group">
                              <label for="pwd">Tema</label>
                              <input type="text" class="form-control" id="topic" name="topic" placeholder="Su asunto de este mensaje."  >
                                              <?php echo form_error('topic'); ?>
                            </div>
                        </div> 
                        <div class="zis-md-12">
                        	<div class="form-group">
                              <label for="pwd">Mensaje</label>
                              <textarea placeholder="Di algo sobre nosotros" name="message" ></textarea>
                                                                            <?php echo form_error('message'); ?>

                            </div>
                        </div> 
                        <input type="submit" value="Enviar Mensaje" name="submit" class="submit-data">    
                    </div>
                </form> 
        </div>    
     </div>
    
    <!--end:inner-media-page-widget -->
        
	
