<!DOCTYPE html>
<html lang="es">
<head>
  
  <title>Contact us</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">  
  <link href="<?php echo base_url(); ?>assets/css/custom-grid.css" rel="stylesheet" type="text/css">
  <!--script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script-->
  <!--script src="js/custom-js.js"></script-->  
  <!--script type = 'text/javascript' src = "<?php echo base_url(); ?>assets/js/javascript.js"></script--> 
  <link type="text/css" href="<?php echo base_url(); ?>assets/css/leanevent.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">    
  
</head>


<body id="scroller-bottom-top" data-spy="scroll" data-target=".navbar" data-offset="50">

  <!--begin:header -->
   <header class="header-section">
         <nav class="navbar navbar-default">
              <div class="container">
                <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>                        
                  </button>
                  <a class="navbar-brand" href="#"><img src="<?php echo base_url(); ?>assets/images/logo-site.png" alt="Logo" width="200" /></a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                   <ul class="nav navbar-nav navbar-right">
                      <li><a href="index.html">Inicio</a></li>
                        <li><a href="about-us.html">Quienes Somos</a></li>
                        <li><a href="http://pujaredij.uta.cloud/REDIJ_LEANEVENT/blog">Blog</a></li>
                        <li><a href="register.php">Registrate</a></li>
                        <li><a href="contact-us.php">Contacto</a></li>
                        <li><a href="login.php">Iniciar Sesión</a></li>
                        <li><a href="buy-from-us.html">Comprar Boletos</a></li>
                  </ul>
                </div>
              </div>
          </nav>
      </header>   
      <!--end:header -->

      <!--begin:inner-media-page-widget -->
     <div class="inner-media-page-widget">
           <div class="media-banner">
          	  <img src="<?php echo base_url(); ?>assets/images/bannerregistro.jpg">
           </div>           
        <div class="container banner-txt-area">
            <div class="zis-md-12">
                <h1 class="main-heading">REGISTRATE</h1>
                <div class="sub-heading"><span>Inicio</span><b>REGISTRATE</b></div>
            </div>
        </div>
     </div>
     <!--begin:inner-media-page-widget -->
     
     
    <div class="register-section">     	
     <h3>Elija el tipo de usauario para registrarse</h3>
            <div class="zis-md-4 zis-btn">
  <input id="myBtn" value="Como individual" class="reg-btn" type="submit">
    
            </div>
			<div class="zis-md-4 zis-btn">
  <input id="myBtn2" value="Como Negocio o Fundacion" class="reg-btn" type="submit">
    
            </div>
			  <div class="zis-md-4 zis-btn">
  <input id="myBtn3" value="Como egnte LEAN" class="reg-btn" type="submit">
    
            </div>
	
	</div>
	
	
	     <!--begin:Pop Up -->
     
	 <div id="myModal" class="modal register-modal">
         <!--?php echo $sidebar;?-->

	 <div class="modal-content">
   <div class="modal-header">
  <!--<span class="close">&times;</span>-->
  <h5>Elija el tipo de usauario para registrarse</h5>
 
</div>

   <div class="register-body">
                <?php echo form_open('Register_controller'); ?>
                	
                    <div class="row">
                    	<div class="zis-md-6">
                        	<div class="form-group">
                              <label for="email_reg">Correo</label>
                              <input class="form-control pop-form-control" id="email_reg" name="email_reg" type="text" placeholder="Correo" >
                                              <?php echo form_error('email_reg'); ?>
                            </div>
                        </div>                        
                        <div class="zis-md-6">
                        	<div class="form-group">
                              <label for="pwd_reg">contrasaera</label>
                              <input class="form-control pop-form-control" id="pwd_reg" name="pwd_reg" type="password" placeholder="Contraseña"  >
                                              <?php echo form_error('pwd_reg'); ?>
                            </div>
                        </div>  
						   	<div class="zis-md-6">
                        	<div class="form-group">
                              <label for="Nombre_reg">Nombre</label>
                              <input class="form-control pop-form-control" id="Nombre_reg" name="Nombre_reg" type="text" placeholder="Tu Nombre" >
                                              <?php echo form_error('Nombre_reg'); ?>
                            </div>
                        </div>                        
                        <div class="zis-md-6">
                        	<div class="form-group">
                              <label for="Apellido_reg">Apellido</label>
                              <input class="form-control pop-form-control" id="Apellido_reg" name="Apellido_reg" type="text" placeholder="Apellido">
                                              <?php echo form_error('Apellido_reg'); ?>
                            </div>
                        </div>  
						    <div class="zis-md-12">
                        	<div class="form-group">
                              <label for="dirección">dirección</label>
                              <input class="form-control pop-form-control" name="address" id="dirección" type="text" placeholder="dirección">
                                              <?php echo form_error('address'); ?>
                            </div>
                        </div>  
						    <div class="zis-md-12">
                        	<div class="form-group">
                              <label for="Ciulad">Ciulad</label>
                              <input class="form-control pop-form-control" name="city" id="Ciulad" type="text" placeholder="Ciulad">
                                              <?php echo form_error('city'); ?>
                            </div>
                        </div>  
							    <div class="zis-md-8">
                        	<div class="form-group">
                              <label for="estado_reg">Estado</label>
                      
							   <select class="form-control pop-form-control" id="estado_reg" name="state" type="text" placeholder="Estado">
              <option value="Select State">Select State</option>    
							<option value="Texas">Texas</option>
              <option value="Michigan">Michigan</option>
              <option value="Florida">Florida</option>
              <option value="Ohio">Ohio</option>
                             </select> 
                                              <?php echo form_error('state'); ?>
                            </div>
                        </div> 
							    <div class="zis-md-4">
                        	<div class="form-group">
                              <label for="postal">Código Postal</label>
                              <input class="form-control pop-form-control" id="postal" name="zip" type="text" placeholder="Código Postal" >
                                              <?php echo form_error('zip'); ?>
                            </div>
                        </div>             
                          <div class="zis-md-12">  <input value="Register" class="register-submit" name="submit" type="submit" ></div>  
                    </div>
                </form>
    </div>
	 <div class="modal-footer form-footer">

   <input value="close" class="submit-data close single-close" type="submit">  
	
    </div>

   
  </div>
	 </div>

      
  <!--End:Pop Up -->




   <!--begin:Pop Up -->
    
   <div id="myModal2" class="modal register-modal">
   <div class="modal-content">
   <div class="modal-header">
  <!--<span class="close">&times;</span>-->
  <h5>Elija el tipo de usauario para registrarse</h5>
 
</div>
   <div class="register-body">
                <?php echo form_open('Register_controller_business'); ?>
                  
                    <div class="row">
                      <div class="zis-md-6">
                          <div class="form-group">
                              <label for="email_reg2">Correo</label>
                              <input class="form-control pop-form-control" id="email_reg2" name="email_reg2" type="text" placeholder="Correo" >
                                              <?php echo form_error('email_reg2'); ?>
                            </div>
                        </div>                        
                         <div class="zis-md-6">
                          <div class="form-group">
                              <label for="pwd_reg2">contrasaera</label>
                              <input class="form-control pop-form-control" id="pwd_reg2" name="pwd_reg2" type="password"  placeholder="Contraseña"  >
                                              <?php echo form_error('pwd_reg2'); ?>
                            </div>
                        </div>  
                <div class="zis-md-6">
                          <div class="form-group">
                              <label for="Nombre_reg2">Nombre</label>
                              <input class="form-control pop-form-control" id="Nombre_reg2" name="Nombre_reg2" type="text" placeholder="Tu Nombre" >
                                              <?php echo form_error('Nombre_reg2'); ?>
                            </div>
                        </div>                        
                        <div class="zis-md-6">
                          <div class="form-group">
                              <label for="Apellido_reg2">Apellido</label>
                              <input class="form-control pop-form-control" id="Apellido_reg2" name="Apellido_reg2" type="text" >
                                              <?php echo form_error('Apellido_reg2'); ?>
                            </div>
                        </div>  
               <div class="zis-md-12">
                          <div class="form-group">
                              <label for="address2">dirección</label>
                              <input class="form-control pop-form-control" id="address2" name="address2" type="text" placeholder="dirección">
                                              <?php echo form_error('address2'); ?>
                            </div>
                        </div>  
                 <div class="zis-md-12">
                          <div class="form-group">
                              <label for="Ciulad2">Ciulad</label>
                              <input class="form-control pop-form-control" id="Ciulad2" name="city2" type="text" placeholder="Ciulad">
                                              <?php echo form_error('city2'); ?>
                            </div>
                        </div>  
                  <div class="zis-md-8">
                          <div class="form-group">
                              <label for="estado_reg2">Estado</label>
                      
                 <select class="form-control pop-form-control" id="estado_reg2" name="state2" type="text" placeholder="Estado">
              <option value="Select State">Select State</option>    
              <option value="Texas">Texas</option>
              <option value="Michigan">Michigan</option>
              <option value="Florida">Florida</option>
              <option value="Ohio">Ohio</option>
                             </select> 
                                              <?php echo form_error('state2'); ?>
                            </div>
                        </div> 
                  <div class="zis-md-4">
                          <div class="form-group">
                              <label for="postal2">Código Postal</label>
                              <input class="form-control pop-form-control" id="postal2" name="zip2" type="text" placeholder="Código Postal">
                                              <?php echo form_error('zip2'); ?>
                            </div>
                        </div> 
            
                 <div class="zis-md-4">
                          <div class="form-group">
                           
                            <input type="radio" name="Tipo de negodo 1" value="Tipo de negodo 1" > Tipo de negodo 1<br>
                            </div>
                                              <?php echo form_error('Tipo de negodo 1'); ?>

                        </div> 
                  <div class="zis-md-4">
                          <div class="form-group">
                             <input type="radio" name="Tipo de negodo 1" value="Tipo de negodo 2"> Tipo de negodo 2<br>
                            </div>
                                              <?php echo form_error('Tipo de negodo 1'); ?>

                        </div> 
              <div class="zis-md-4">
                          <div class="form-group">
                             <input type="radio" name="Tipo de negodo 1" value="Tipo de negodo 3"> Tipo de negodo 3<br>
                            </div>
                                              <?php echo form_error('Tipo de negodo 1'); ?>

                        </div> 
                          <div class="zis-md-12">  <input value="Register" class="register-submit" type="submit" name="submit2" ></div>  


          
                    </div>
                </form>
    </div>
   <div class="modal-footer form-footer">

   <input value="close" class="submit-data close2 single-close" type="submit">  
  
    </div>
   
  </div>
   </div>

     

  <!--End:Pop Up -->
    <!--begin:Pop Up -->
    
   <div id="myModal3" class="modal register-modal">
   <div class="modal-content">
   <div class="modal-header">
  <!--<span class="close">&times;</span>-->
  <h5>Elija el tipo de usauario para registrarse</h5>
 
</div>
 
   <div class="register-body">
                <?php echo form_open('Register_controller_agentlean'); ?>
                  
                    <div class="row">
                      <div class="zis-md-6">
                          <div class="form-group">
                              <label for="email_reg1">Correo</label>
                              <input class="form-control pop-form-control" id="email_reg1" name="email_reg1" type="text" placeholder="Correo" >
                                              <?php echo form_error('email_reg1'); ?>
                            </div>
                        </div>                        
                        <div class="zis-md-6">
                          <div class="form-group">
                              <label for="pwd_reg1">contrasaera</label>
                              <input class="form-control pop-form-control" id="pwd_reg1" name="pwd_reg1" type="password"  placeholder="Contraseña" >
                                              <?php echo form_error('pwd_reg1'); ?>
                            </div>
                        </div>  
                <div class="zis-md-6">
                          <div class="form-group">
                              <label for="Nombre_reg1">Nombre</label>
                              <input class="form-control pop-form-control" id="Nombre_reg1" name="Nombre_reg1" type="text" placeholder="Tu Nombre">
                                              <?php echo form_error('Nombre_reg1'); ?>
                            </div>
                        </div>                        
                        <div class="zis-md-6">
                          <div class="form-group">
                              <label for="Apellido_reg1">Apellido</label>
                              <input class="form-control pop-form-control" id="Apellido_reg1" name="Apellido_reg1" type="text" >
                                              <?php echo form_error('Apellido_reg1'); ?>
                            </div>
                        </div>  
                        <div class="zis-md-12">
                          <div class="form-group">
                              <label for="dirección1">dirección</label>
                              <input class="form-control pop-form-control" id="dirección1" name="address1" type="text" placeholder="dirección">
                                              <?php echo form_error('address1'); ?>
                            </div>
                        </div>  
                <div class="zis-md-12">
                          <div class="form-group">
                              <label for="Ciulad1">Ciulad</label>
                              <input class="form-control pop-form-control" name="city1" id="Ciulad1" type="text" placeholder="Ciulad">
                                              <?php echo form_error('city1'); ?>
                            </div>
                        </div>  
                  <div class="zis-md-8">
                          <div class="form-group">
                              <label for="estado_reg1">Estado</label>
                 <select class="form-control pop-form-control" name="state1" id="estado_reg1" type="text" placeholder="Estado">
              <option value="Select State">Select State</option>    
              <option value="Texas">Texas</option>
              <option value="Michigan">Michigan</option>
              <option value="Florida">Florida</option>
              <option value="Ohio">Ohio</option>
                             </select> 
                                              <?php echo form_error('state1'); ?>
                            </div>
                        </div> 
                  <div class="zis-md-4">
                          <div class="form-group">
                              <label for="postal1">Código Postal</label>
                              <input class="form-control pop-form-control" name="zip1" id="postal1" type="text" placeholder="Código Postal" >
                                              <?php echo form_error('zip1'); ?>
                            </div>
                        </div>              
                          <div class="zis-md-12"><input value="Register" class="register-submit" name="submit1" type="submit"></div>        
                    </div>
                </form>
    </div>
   <div class="modal-footer form-footer">

   <input value="close" class="submit-data close3 single-close" type="submit">  
  
    </div>

    
  </div>
   </div>

     
  <!--End:Pop Up -->

  <script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
<script>
// Get the modal
var modal2 = document.getElementById('myModal2');

// Get the button that opens the modal
var btn2 = document.getElementById("myBtn2");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close2")[0];

// When the user clicks the button, open the modal 
btn2.onclick = function() {
  modal2.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal2.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal2) {
    modal2.style.display = "none";
  }
}
</script>
<script>
// Get the modal
var modal3 = document.getElementById('myModal3');

// Get the button that opens the modal
var btn3 = document.getElementById("myBtn3");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close3")[0];

// When the user clicks the button, open the modal 
btn3.onclick = function() {
  modal3.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal3.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal3) {
    modal3.style.display = "none";
  }
}
</script>


<!--begin:footer-->
  <footer>
      <div class="container">
            <div class="heading-ft">Registrese para recibir un boletín</div>
                <ul class="footer-social">
                  <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                </ul>
                <div class="copy-right">Copyright @2019 All rights reserved | This web is made with &#9825 by <a href="#">DiazApps</a></div>
        </div>  
        
        <a href="#scroller-bottom-top" class="home-tag-ft"><i class="fas fa-arrow-up"></i></a>    </footer>
    <!--end:footer-->
   
  
  <!--script src="js/javascript.js"></script--> 
</body>
</html>

