<!--begin:footer-->
	<footer>
    	<div class="container">
        		<div class="heading-ft">Registrese para recibir un boletín</div>
                <ul class="footer-social">
                	<li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                </ul>
                <div class="copy-right">Copyright @2019 All rights reserved | This web is made with &#9825 by <a href="#">DiazApps</a></div>
        </div>  
        
        <a href="#scroller-bottom-top" class="home-tag-ft"><i class="fas fa-arrow-up"></i></a>    </footer>
    <!--end:footer-->
   
  
  <!--script src="js/javascript.js"></script--> 
</body>
</html>

