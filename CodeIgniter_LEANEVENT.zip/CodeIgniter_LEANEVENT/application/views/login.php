<!DOCTYPE html>
<html lang="es">
<head>
  
  <title>Contact us</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">  
  <link href="<?php echo base_url(); ?>assets/css/custom-grid.css" rel="stylesheet" type="text/css">
  <!--script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script-->
  <!--script src="js/custom-js.js"></script-->  
  <!--script type = 'text/javascript' src = "<?php echo base_url(); ?>assets/js/javascript.js"></script--> 
  <link type="text/css" href="<?php echo base_url(); ?>assets/css/leanevent.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">    
  
</head>


<body id="scroller-bottom-top" data-spy="scroll" data-target=".navbar" data-offset="50">

  <!--begin:header -->
   <header class="header-section">
         <nav class="navbar navbar-default">
              <div class="container">
                <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>                        
                  </button>
                  <a class="navbar-brand" href="#"><img src="<?php echo base_url(); ?>assets/images/logo-site.png" alt="Logo" width="200" /></a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                   <ul class="nav navbar-nav navbar-right">
                      <li><a href="index.html">Inicio</a></li>
                        <li><a href="about-us.html">Quienes Somos</a></li>
                        <li><a href="http://pujaredij.uta.cloud/REDIJ_LEANEVENT/blog">Blog</a></li>
                        <li><a href="register.php">Registrate</a></li>
                        <li><a href="contact-us.php">Contacto</a></li>
                        <li><a href="login.php">Iniciar Sesión</a></li>
                        <li><a href="buy-from-us.html">Comprar Boletos</a></li>
                  </ul>
                </div>
              </div>
          </nav>
      </header>   
      <!--end:header -->
      
      
	  
	 <!--begin:inner-media-page-widget -->
     <div class="inner-media-page-widget">
           <div class="media-banner">
          	  <img src="<?php echo base_url(); ?>assets/images/bannerlogin.jpg">
           </div>           
        <div class="container banner-txt-area">
            <div class="zis-md-12">
                <h1 class="main-heading">Iniciar Sesión</h1>
                <div class="sub-heading"><span>Inicio</span><b>Iniciar Sesión</b></div>
            </div>
        </div>
     </div>
     <!--begin:inner-media-page-widget -->
     
     
     
     
     <!--begin:inner-media-page-widget -->
     <div class="logo-form">
     	<div class="container-logo">     	
                <?php echo form_open('Login_controller'); ?>
                	<h3>Iniciar Sesión</h3>
                    <div class="row">
                    	<div class="zis-md-6">
                        	<div class="form-group">
                              <label for="usr">Nombre de Usuario</label>
                              <!--input type="text" class="form-control" id="username" name="username" placeholder="Nombre de Usuario o Correo" required pattern="[A-Za-z]{1,15}+ | [a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"-->
                              <input type="text" class="form-control" id="username" name="username" placeholder="Nombre de Usuario o Correo" >
                                              <?php echo form_error('username'); ?>
                            </div>
                        </div>                        
                        <div class="zis-md-6">
                        	<div class="form-group">
                              <label for="pwd">Contraseña</label>
                              <input type="password" class="form-control" id="login_pwd" name="login_pwd"  placeholder="Contraseña" >
                                              <?php echo form_error('login_pwd'); ?>
                            </div>
                        </div>  
                        <a href="#" class="for-pass"><label for="reset-toggle">Olvido so contraseña</label></a>

                       


                        <input type="submit" value="Entra" name="submit" class="submit-data" >  

                         <input type ="checkbox" id="reset-toggle" value="link" style="visibility: hidden;">

                        <dialog > 
                        
                        <div class="reset_content"> 
                                          <form id="reset_form" novalidate>
                                            <h3>Recuperar Su Contraseña</h3>
                                            <label for="reset_pwd">Correo</label>
                                            <input type="email" id="reset_pwd" name="reset_pwd" placeholder="Correo" style="width:100%" >
                                            <p id="error_reset"></p>
                                            <input type="submit" value="Enviar" name="reset_submit" class="submit-data">  
                                        </form>
    </div>
   <label for="reset-toggle">Cerrar</label>
</dialog>

                    </div>
                </form> 
        </div>    
     </div>
    <!--end:inner-media-page-widget -->
    
    
    
	<!--begin:footer-->
  <footer>
      <div class="container">
            <div class="heading-ft">Registrese para recibir un boletín</div>
                <ul class="footer-social">
                  <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                </ul>
                <div class="copy-right">Copyright @2019 All rights reserved | This web is made with &#9825 by <a href="#">DiazApps</a></div>
        </div>  
        
        <a href="#scroller-bottom-top" class="home-tag-ft"><i class="fas fa-arrow-up"></i></a>    </footer>
    <!--end:footer-->
   
  
  <!--script src="js/javascript.js"></script--> 
</body>
</html>


